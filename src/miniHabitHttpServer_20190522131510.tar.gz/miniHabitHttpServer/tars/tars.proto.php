<?php
/**
 * Created by PhpStorm.
 * User: chengxiaoli
 * Date: 2019/5/17
 * Time: 下午8:03
 */
return array(
    'appName' => 'php',
    'serverName' => 'miniHabitHttpServer',
    'objName' => 'obj',
);